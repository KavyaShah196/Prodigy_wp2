let startTime, updatedTime, difference, timerId;
let paused = true;
let laps = [];

const display = document.getElementById('display');
const lapsList = document.getElementById('laps');

document.getElementById('start').addEventListener('click', start);
document.getElementById('pause').addEventListener('click', pause);
document.getElementById('reset').addEventListener('click', reset);
document.getElementById('lap').addEventListener('click', recordLap);

function start() {
    if (paused) {
        paused = false;
        startTime = startTime ? startTime : Date.now() - (difference || 0);
        timerId = setInterval(updateTime, 10);
    }
}

function pause() {
    if (!paused) {
        paused = true;
        clearInterval(timerId);
        difference = Date.now() - startTime;
    }
}

function reset() {
    paused = true;
    clearInterval(timerId);
    startTime = null;
    updatedTime = 0;
    difference = 0;
    laps = [];
    display.innerHTML = '00:00:00';
    lapsList.innerHTML = '';
}

function updateTime() {
    updatedTime = Date.now() - startTime;
    display.innerHTML = formatTime(updatedTime);
}

function formatTime(ms) {
    let date = new Date(ms);
    let minutes = String(date.getUTCMinutes()).padStart(2, '0');
    let seconds = String(date.getUTCSeconds()).padStart(2, '0');
    let milliseconds = String(date.getUTCMilliseconds()).padStart(3, '0').slice(0, 2);
    return `${minutes}:${seconds}:${milliseconds}`;
}

function recordLap() {
    if (!paused) {
        laps.push(updatedTime);
        let lapItem = document.createElement('li');
        lapItem.textContent = formatTime(updatedTime);
        lapsList.appendChild(lapItem);
    }
}
